import sys, pygame

pygame.init()

# VARS

run = True

default = 800, 600  # Screen default size

# Currently "PNG" format throw a warning
# on running because of the format it
# should be bmp but it looks bad

player = pygame.image.load("prb.png")
background = pygame.image.load("bdrm.png")

# For displaying full screen pygame.FULLSCREEN
screen = pygame.display.set_mode(default)

# Other screen issues
pygame.display.set_caption("RPG")
screen.blit(background, (0, 0))
position = player.get_rect()
screen.blit(player, position)
pygame.display.update()

while run:
    for event in pygame.event.get():
        if event.type == pygame.key.get_pressed():
            if event
        if event.type == pygame.QUIT or event.type == pygame.K_ESCAPE:
            run = False

pygame.quit()
