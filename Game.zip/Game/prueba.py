import sys, pygame

pygame.init()
size = 800, 600
screen = pygame.display.set_mode(size)
player = pygame.image.load("prb.png").convert()
terrain = pygame.image.load("bdrm.png").convert()
screen.blit(terrain, (0, 0))
position = player.get_rect()
screen.blit(player, position)
pygame.display.update()
for X in range(100):
    screen.blit(terrain, position, position)
    position = position.move(2, 0)
    screen.blit(player, position)
    pygame.display.update()
    pygame.time.delay(100)

